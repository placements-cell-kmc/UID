import { useServerFn } from "@tanstack/react-start";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Check, FileCheck2, LockKeyhole, ShieldCheck, UploadCloud } from "lucide-react";
import { useEffect, useRef, useState, type FormEvent } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { checkIsAdmin, getPortalSettings, getRequestStatus, listCourses, submitStudentRequest } from "@/lib/portal.functions";
import logo from "@/assets/avenues-logo.png";
import campus from "@/assets/kmc-campus.jpg";

function AuthButton() {
  const navigate = useNavigate();
  const isAdminFn = useServerFn(checkIsAdmin);
  const [email, setEmail] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const route = async () => {
      const { data } = await supabase.auth.getUser();
      setEmail(data.user?.email ?? null);
      if (data.user) {
        try { if (await isAdminFn()) void navigate({ to: "/admin" }); } catch { /* student */ }
      }
    };
    void route();
    const { data: sub } = supabase.auth.onAuthStateChange((event) => { if (event === "SIGNED_IN" || event === "SIGNED_OUT") void route(); });
    return () => sub.subscription.unsubscribe();
  }, [isAdminFn, navigate]);
  const signIn = async () => {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin, extraParams: { prompt: "select_account" } });
    if (result.error) window.alert("Google sign-in could not be started.");
    setBusy(false);
  };
  if (email) return <div className="flex items-center gap-3 text-sm"><span className="hidden text-brand-paper/75 sm:inline">{email}</span><button onClick={() => void supabase.auth.signOut()} className="border border-brand-paper/60 px-3 py-2 font-display text-xs uppercase tracking-wide hover:bg-brand-paper hover:text-brand-ink">Sign out</button></div>;
  return <button disabled={busy} onClick={() => void signIn()} className="border border-brand-paper/60 px-4 py-2 font-display text-sm uppercase tracking-wide text-brand-paper transition hover:bg-brand-paper hover:text-brand-ink">{busy ? "Opening…" : "Sign in with Google"}</button>;
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "UID Registration | Avenues – The Placement Cell" },
      { name: "description", content: "Register for your official Avenues UID through the Kirori Mal College Placement Cell." },
      { property: "og:title", content: "UID Registration | Avenues – The Placement Cell" },
      { property: "og:description", content: "Register for your official Avenues UID through the Kirori Mal College Placement Cell." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PortalHome,
});

type Course = { id: string; name: string; acronym: string };
type Submitted = { reference_id: string; status: string };
type TrackResult = { reference_id: string; status: string; status_reason: string | null; uid: string | null };

function PortalHome() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [batch, setBatch] = useState("2029/30");
  const [mode, setMode] = useState<"home" | "form" | "track" | "success">("home");
  const [submitted, setSubmitted] = useState<Submitted | null>(null);
  const coursesFn = useServerFn(listCourses);
  const settingsFn = useServerFn(getPortalSettings);

  useEffect(() => {
    Promise.all([coursesFn(), settingsFn()]).then(([courseRows, settings]) => {
      setCourses(courseRows as Course[]);
      setBatch(settings.active_batch);
    }).catch(() => undefined);
  }, [coursesFn, settingsFn]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-brand-paper/15 bg-brand-ink text-brand-paper">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-10">
          <Link to="/" className="flex items-center gap-3" aria-label="Avenues UID Portal home">
            <img src={logo} alt="Avenues – The Placement Cell" className="h-14 w-14 object-contain" />
          </Link>
          <nav className="hidden items-center gap-8 font-display text-sm uppercase tracking-wide md:flex">
            <a href="https://www.placementcellkmc.com/" className="text-brand-paper/85 transition hover:text-brand-paper">Home</a>
            <a href="#how-it-works" className="text-brand-paper/85 transition hover:text-brand-paper">How it works</a>
            <a href="#support" className="text-brand-paper/85 transition hover:text-brand-paper">Contact us</a>
          </nav>
          <AuthButton />
        </div>
      </header>

      {mode === "home" && <HomeScreen batch={batch} onStart={() => setMode("form")} onTrack={() => setMode("track")} />}
      {mode === "form" && <RequestForm courses={courses} onBack={() => setMode("home")} onSubmitted={(result) => { setSubmitted(result); setMode("success"); }} />}
      {mode === "track" && <TrackRequest onBack={() => setMode("home")} />}
      {mode === "success" && submitted && <SuccessScreen referenceId={submitted.reference_id} onTrack={() => setMode("track")} onHome={() => setMode("home")} />}

      <footer id="support" className="bg-brand-ink text-brand-paper [&_p]:text-brand-paper/80 [&_.text-brand-ink]:text-brand-paper">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 py-10 text-sm text-muted-foreground md:grid-cols-3 lg:px-10">
          <div><p className="font-display text-2xl text-brand-ink">Avenues</p><p className="mt-2 max-w-xs">The Placement Cell, Kirori Mal College<br />University of Delhi</p></div>
          <div><p className="font-semibold uppercase tracking-[0.16em] text-brand-ink">Need help?</p><p className="mt-2">Contact the Placement Cell for registration support.</p></div>
          <div className="md:text-right"><p className="font-semibold uppercase tracking-[0.16em] text-brand-ink">Privacy first</p><p className="mt-2">Your details are used only for UID registration and official communication.</p></div>
        </div>
      </footer>
    </div>
  );
}

function HomeScreen({ batch, onStart, onTrack }: { batch: string; onStart: () => void; onTrack: () => void }) {
  return (
    <main>
      <section className="relative overflow-hidden bg-brand-ink">
        <img src={campus} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 bg-brand-ink/50" />
        <div className="relative mx-auto max-w-5xl px-5 py-24 text-center lg:py-32">
          <p className="font-display text-xs uppercase tracking-[0.3em] text-brand-paper/80">Avenues – The Placement Cell · KMC</p>
          <h1 className="mt-6 font-display text-4xl uppercase leading-tight tracking-wide text-brand-paper sm:text-5xl lg:text-6xl">UID Registration Portal</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-brand-paper/90">Register for your official Avenues UID and stay connected to every placement opportunity floated by the Placement Cell.</p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button onClick={onStart} size="lg" className="h-12 rounded-none bg-brand-paper px-8 font-display uppercase tracking-wide text-brand-ink hover:bg-brand-paper/90">Generate UID <ArrowRight /></Button>
            <Button onClick={onTrack} size="lg" variant="outline" className="h-12 rounded-none border-brand-paper/70 bg-transparent px-8 font-display uppercase tracking-wide text-brand-paper hover:bg-brand-paper/10 hover:text-brand-paper">Track request</Button>
          </div>
          <p className="mt-6 font-display text-xs uppercase tracking-[0.2em] text-brand-paper/70">Note: Only for Batch {batch}</p>
        </div>
      </section>
      <section id="how-it-works" className="bg-brand-ink px-5 py-20 lg:px-10">
        <div className="mx-auto max-w-7xl text-center">
          <h2 className="font-display text-3xl uppercase tracking-wide text-brand-paper sm:text-4xl">How it works</h2>
          <p className="mx-auto mt-4 max-w-2xl text-brand-paper/85">A simple, verified process built for the students of Kirori Mal College.</p>
          <div className="mt-12 grid gap-6 text-left md:grid-cols-3">
            <Step icon={<FileCheck2 />} number="01" title="Submit" body="Share your details and a valid College ID document." />
            <Step icon={<ShieldCheck />} number="02" title="Review" body="The Placement Cell verifies every request carefully." />
            <Step icon={<UploadCloud />} number="03" title="Receive" body="Your unique UID is issued and shared with you." />
          </div>
        </div>
      </section>
      <section className="bg-background px-5 py-20 lg:px-10">
        <div className="mx-auto max-w-6xl text-center">
          <h2 className="font-display text-3xl uppercase tracking-wide text-brand-ink sm:text-4xl">Why register</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            <Trust dark icon={<ShieldCheck />} title="Verified process" body="Every request is reviewed by the Placement Cell." />
            <Trust dark icon={<LockKeyhole />} title="Private by default" body="Your ID document is visible only to authorised reviewers." />
            <Trust dark icon={<FileCheck2 />} title="One identity" body="Use your UID across all official placement communication." />
          </div>
          <Button onClick={onStart} className="mt-12 h-11 rounded-none bg-brand-ink px-8 font-display uppercase tracking-wide text-brand-paper hover:bg-brand-ink/90">Start registration <ArrowRight /></Button>
        </div>
      </section>
    </main>
  );
}

const YEAR_OPTIONS = ["2029/30 (First Year)", "2028/29 (Second Year)", "2027/28 (Third Year)", "2027 (Fourth Year)"];
const wizardInput = "h-12 rounded-md border-0 bg-white text-[15px] text-brand-ink placeholder:text-muted-foreground";
const wizardSelect = "h-12 w-full rounded-md border-0 bg-white px-3 text-[15px] text-brand-ink";
const circleBase = "grid h-11 w-11 place-items-center rounded-full font-display";
const stepButton = "h-12 rounded-md font-display text-sm uppercase tracking-[0.2em]";

function Stepper({ step }: { step: 1 | 2 }) {
  return (
    <div className="flex items-start">
      <div className="flex w-28 flex-col items-center sm:w-40">
        <span className={`${circleBase} ${step === 2 ? "bg-brand-paper text-brand-ink" : "bg-brand-paper text-brand-ink shadow-[0_0_0_7px_rgba(255,255,255,0.08)]"}`}>
          {step === 2 ? <Check className="h-5 w-5" /> : "1"}
        </span>
        <span className={`mt-3 font-display text-sm ${step === 2 ? "text-brand-paper" : "text-brand-paper"}`}>Your Details</span>
      </div>
      <div className={`mx-2 mt-5 h-px flex-1 ${step === 2 ? "bg-brand-paper/80" : "bg-brand-paper/40"}`} />
      <div className="flex w-28 flex-col items-center sm:w-40">
        <span className={`${circleBase} ${step === 2 ? "bg-brand-paper text-brand-ink shadow-[0_0_0_7px_rgba(255,255,255,0.08)]" : "bg-brand-paper/15 text-brand-paper/70"}`}>2</span>
        <span className={`mt-3 text-center font-display text-sm ${step === 2 ? "text-brand-paper" : "text-brand-paper/55"}`}>Review &amp; Submit</span>
      </div>
    </div>
  );
}

function WizardField({ label, error, children }: { label: string; error?: string | undefined; children: React.ReactNode }) {
  return (
    <div>
      <span className="text-xs font-semibold uppercase tracking-[0.08em] text-brand-paper/85">{label} <span className="text-destructive">*</span></span>
      <div className="mt-2">{children}</div>
      {error && <p role="alert" className="mt-1.5 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function ReviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 py-4">
      <span className="text-xs uppercase tracking-[0.08em] text-brand-paper/60">{label}</span>
      <span className="text-right text-sm text-brand-paper">{value}</span>
    </div>
  );
}

type ErrorKey = "fullName" | "courseId" | "rollNumber" | "year" | "phone" | "email" | "file";

function RequestForm({ courses, onBack, onSubmitted }: { courses: Course[]; onBack: () => void; onSubmitted: (result: Submitted) => void }) {
  const [step, setStep] = useState<1 | 2>(1);
  const [form, setForm] = useState({ fullName: "", courseId: "", rollNumber: "", year: "", phone: "", email: "" });
  const [file, setFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<Partial<Record<ErrorKey, string>>>({});
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState("");
  const submitFn = useServerFn(submitStudentRequest);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => { cardRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }); }, [step]);

  const set = (key: keyof typeof form) => (value: string) => setForm((current) => ({ ...current, [key]: value }));
  const clearError = (key: ErrorKey) => setErrors((current) => { const next = { ...current }; delete next[key]; return next; });
  const onFile = (candidate: File | undefined) => {
    if (!candidate) return;
    if (!["image/jpeg", "image/png"].includes(candidate.type) || candidate.size > 5 * 1024 * 1024) {
      setErrors((current) => ({ ...current, file: "Please choose a JPG or PNG under 5 MB." }));
      return;
    }
    clearError("file");
    setFile(candidate);
  };

  const validateStep1 = () => {
    const next: Partial<Record<ErrorKey, string>> = {};
    if (!form.fullName.trim()) next.fullName = "Please enter your full name.";
    else if (!/^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'-]+$/.test(form.fullName.trim())) next.fullName = "Please enter a valid name (letters and spaces only).";
    if (!form.courseId) next.courseId = "Please select your course.";
    if (!form.rollNumber.trim()) next.rollNumber = "Please enter your roll number.";
    if (!form.year) next.year = "Please select your year of graduation.";
    if (!/^[6-9]\d{9}$/.test(form.phone)) next.phone = "Please enter a valid 10-digit mobile number.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) next.email = "Please enter a valid email address.";
    if (!file) next.file = "Please attach a photo of your College ID.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const courseName = courses.find((course) => course.id === form.courseId)?.name ?? "";

  const submit = async () => {
    if (!file) return;
    setFormError("");
    setBusy(true);
    try {
      const path = `requests/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "-")}`;
      const { error: uploadError } = await supabase.storage.from("college-id-uploads").upload(path, file, { contentType: file.type, upsert: false });
      if (uploadError) throw new Error("Your ID photo could not be uploaded. Please try again.");
      const result = await submitFn({ data: { fullName: form.fullName.trim(), courseId: form.courseId, rollNumber: form.rollNumber.trim(), yearOfGraduation: form.year, phone: form.phone.replace(/\D/g, ""), email: form.email.trim(), collegeIdPath: path, collegeIdMime: file.type as "image/jpeg" | "image/png", collegeIdSize: file.size } });
      onSubmitted(result as Submitted);
    } catch (caught) {
      setFormError(caught instanceof Error ? caught.message : "Your request could not be submitted.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="bg-brand-ink">
      <section className="relative overflow-hidden bg-brand-ink">
        <img src={campus} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-brand-ink/60" />
        <div className="relative mx-auto max-w-5xl px-5 py-28 text-center lg:py-36">
          <h1 className="font-display text-4xl uppercase tracking-wide text-brand-paper sm:text-5xl lg:text-6xl">UID Request Portal</h1>
          <p className="mt-5 font-display text-lg text-brand-paper/90 sm:text-xl">Request Your Unique PC ID</p>
        </div>
      </section>
      <section className="px-5 pb-24 pt-14 lg:pb-32">
        <div className="mx-auto max-w-3xl">
          <button onClick={onBack} className="mb-12 font-display text-sm uppercase tracking-[0.16em] text-brand-paper/60 transition hover:text-brand-paper">← Back to portal</button>
          <Stepper step={step} />
          <div ref={cardRef} className="mt-12 scroll-mt-8 rounded-lg border border-brand-paper/20 bg-brand-paper/5 px-6 py-10 sm:px-10 lg:px-14">
            {step === 1 ? (
              <>
                <h2 className="text-center font-display text-3xl uppercase tracking-wide text-brand-paper sm:text-4xl">Your Details</h2>
                <p className="mt-3 text-center text-sm text-brand-paper/60">Please provide your information to request your Unique PC ID</p>
                <form noValidate className="mt-10 space-y-7" onSubmit={(event) => { event.preventDefault(); setFormError(""); if (validateStep1()) setStep(2); }}>
                  <WizardField label="Student name" error={errors.fullName}>
                    <Input value={form.fullName} onChange={(event) => { set("fullName")(event.target.value); clearError("fullName"); }} placeholder="Enter your full name" className={wizardInput} />
                  </WizardField>
                  <WizardField label="Course" error={errors.courseId}>
                    <select required value={form.courseId} onChange={(event) => { set("courseId")(event.target.value); clearError("courseId"); }} className={`${wizardSelect} ${form.courseId ? "" : "text-muted-foreground"}`} aria-label="Course">
                      <option value="" disabled>Select a course</option>
                      {courses.map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}
                    </select>
                  </WizardField>
                  <WizardField label="Roll number" error={errors.rollNumber}>
                    <Input value={form.rollNumber} onChange={(event) => { set("rollNumber")(event.target.value); clearError("rollNumber"); }} placeholder="Enter your roll number" className={wizardInput} />
                  </WizardField>
                  <WizardField label="Year of graduation" error={errors.year}>
                    <select required value={form.year} onChange={(event) => { set("year")(event.target.value); clearError("year"); }} className={`${wizardSelect} ${form.year ? "" : "text-muted-foreground"}`} aria-label="Year of graduation">
                      <option value="" disabled>Select year</option>
                      {YEAR_OPTIONS.map((year) => <option key={year} value={year}>{year}</option>)}
                    </select>
                  </WizardField>
                  <WizardField label="Phone number" error={errors.phone}>
                    <Input inputMode="numeric" maxLength={10} value={form.phone} onChange={(event) => { set("phone")(event.target.value.replace(/\D/g, "")); clearError("phone"); }} placeholder="Enter your phone number" className={wizardInput} />
                  </WizardField>
                  <WizardField label="Email address" error={errors.email}>
                    <Input type="email" value={form.email} onChange={(event) => { set("email")(event.target.value); clearError("email"); }} placeholder="Enter your email" className={wizardInput} />
                  </WizardField>
                  <WizardField label="ID photo" error={errors.file}>
                    <label onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); onFile(event.dataTransfer.files?.[0]); }} className="flex min-h-28 cursor-pointer flex-col items-center justify-center gap-1 rounded-md border border-dashed border-brand-paper/40 bg-brand-paper/5 px-5 py-4 text-center transition hover:border-brand-paper/70">
                      <input type="file" accept="image/jpeg,image/png" className="sr-only" onChange={(event) => { onFile(event.target.files?.[0]); event.target.value = ""; }} />
                      <UploadCloud className="h-6 w-6 text-brand-paper/70" />
                      <span className="text-sm text-brand-paper/85">{file ? file.name : "Choose a photo or drop it here"}</span>
                      <span className="text-xs text-brand-paper/55">JPG/PNG, max 5MB</span>
                    </label>
                  </WizardField>
                  {formError && <p role="alert" className="border-l-2 border-destructive bg-destructive/10 px-4 py-3 text-sm text-destructive">{formError}</p>}
                  <Button type="submit" className={`w-full bg-brand-paper text-brand-ink hover:bg-brand-paper/90 ${stepButton}`}>Continue</Button>
                </form>
              </>
            ) : (
              <>
                <h2 className="text-center font-display text-3xl uppercase tracking-wide text-brand-paper sm:text-4xl">Review Your Details</h2>
                <p className="mt-3 text-center text-sm text-brand-paper/60">Please verify your information before submitting</p>
                <div className="mt-8 divide-y divide-brand-paper/15 rounded-md border border-brand-paper/15 bg-brand-ink-soft px-5">
                  <ReviewRow label="Student name" value={form.fullName.trim()} />
                  <ReviewRow label="Course" value={courseName} />
                  <ReviewRow label="Roll number" value={form.rollNumber.trim()} />
                  <ReviewRow label="Year of graduation" value={form.year} />
                  <ReviewRow label="Phone" value={form.phone} />
                  <ReviewRow label="Email" value={form.email.trim()} />
                </div>
                {formError && <p role="alert" className="mt-6 border-l-2 border-destructive bg-destructive/10 px-4 py-3 text-sm text-destructive">{formError}</p>}
                <div className="mt-8 grid gap-4 sm:grid-cols-2">
                  <Button type="button" disabled={busy} onClick={() => setStep(1)} variant="outline" className={`${stepButton} border-brand-paper/70 bg-transparent text-brand-paper hover:bg-brand-paper/10 hover:text-brand-paper`}>Back</Button>
                  <Button type="button" disabled={busy} onClick={() => void submit()} className={`${stepButton} bg-brand-paper text-brand-ink hover:bg-brand-paper/90`}>{busy ? "Submitting…" : "Submit request"}</Button>
                </div>
                <p className="mt-6 text-center text-xs text-brand-paper/50">By submitting, you agree that these details and your ID photo may be used for UID registration and official Placement Cell communication.</p>
              </>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
function Trust({ icon, title, body }: { icon: React.ReactNode; title: string; body: string; dark?: boolean }) { return <div className="rounded-md bg-brand-ink px-6 py-8 text-center text-brand-paper"><div className="mx-auto flex justify-center [&_svg]:h-8 [&_svg]:w-8">{icon}</div><h3 className="mt-4 font-display uppercase tracking-wide">{title}</h3><p className="mt-2 text-sm text-brand-paper/80">{body}</p></div>; }

function Step({ icon, number, title, body }: { icon: React.ReactNode; number: string; title: string; body: string }) {
  return (
    <div className="rounded-md border border-brand-paper/20 bg-brand-paper/5 px-6 py-8">
      <div className="flex items-center justify-between">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-paper/10 text-brand-paper [&_svg]:h-5 [&_svg]:w-5">{icon}</div>
        <span className="font-display text-3xl text-brand-paper/30">{number}</span>
      </div>
      <h3 className="mt-5 font-display text-lg uppercase tracking-wide text-brand-paper">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-brand-paper/75">{body}</p>
    </div>
  );
}

function TrackRequest({ onBack }: { onBack: () => void }) { const [referenceId, setReferenceId] = useState(""); const [result, setResult] = useState<TrackResult | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false); const statusFn = useServerFn(getRequestStatus); const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(""); try { const data = await statusFn({ data: { referenceId } }); setResult(data as TrackResult); } catch (caught) { setError(caught instanceof Error ? caught.message : "We could not find that request."); } finally { setBusy(false); } }; return <main className="min-h-[65vh] bg-brand-paper"><div className="mx-auto max-w-xl px-5 py-16 lg:py-24"><button onClick={onBack} className="mb-10 text-sm text-muted-foreground underline underline-offset-4 hover:text-brand-ink">← Back to portal</button><p className="text-xs font-bold uppercase tracking-[0.25em] text-brand-gold">Request tracker</p><h1 className="mt-4 font-display text-6xl leading-none text-brand-ink">Check your<br /><em>status.</em></h1><p className="mt-5 text-muted-foreground">Enter the reference ID from your acknowledgement screen.</p><form onSubmit={submit} className="mt-10 flex gap-3"><Input required value={referenceId} onChange={(event) => setReferenceId(event.target.value.toUpperCase())} placeholder="AVN-XXXXXXXX" className="h-12 uppercase" /><Button disabled={busy} type="submit" className="h-12 rounded-none bg-brand-ink text-brand-paper hover:bg-brand-ink/90">{busy ? "Checking…" : "Check"}</Button></form>{error && <p role="alert" className="mt-5 text-sm text-destructive">{error}</p>}{result && <div className="mt-10 border border-border bg-background p-6"><p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">{result.reference_id}</p><p className="mt-4 font-display text-4xl text-brand-ink">{statusLabel(result.status)}</p>{result.uid && <p className="mt-3 font-mono text-lg tracking-widest text-brand-gold">{result.uid}</p>}{result.status_reason && <p className="mt-4 text-sm text-muted-foreground">{result.status_reason}</p>}</div>}</div></main>; }
function statusLabel(status: string) { return status === "approved" ? "Approved" : status === "rejected" ? "Not approved" : status === "correction_requested" ? "Correction needed" : "Under review"; }
function SuccessScreen({ referenceId, onTrack, onHome }: { referenceId: string; onTrack: () => void; onHome: () => void }) { return <main className="min-h-[65vh] bg-brand-paper"><div className="mx-auto max-w-2xl px-5 py-20 text-center lg:py-28"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-brand-gold text-brand-ink"><Check className="h-8 w-8" /></div><p className="mt-8 text-xs font-bold uppercase tracking-[0.25em] text-brand-gold">Registration received</p><h1 className="mt-4 font-display text-6xl leading-none text-brand-ink">You’re on your<br /><em>way.</em></h1><p className="mx-auto mt-6 max-w-md leading-7 text-muted-foreground">Your request is under review. Keep this reference ID safe — we’ll use it to help you track your request.</p><div className="mx-auto mt-8 max-w-sm border border-border bg-background px-6 py-5"><p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Reference ID</p><p className="mt-2 font-mono text-2xl tracking-widest text-brand-ink">{referenceId}</p></div><div className="mt-8 flex justify-center gap-3"><Button variant="outline" onClick={onTrack} className="rounded-none">Track request</Button><Button onClick={onHome} className="rounded-none bg-brand-ink text-brand-paper hover:bg-brand-ink/90">Back to home</Button></div></div></main>; }
