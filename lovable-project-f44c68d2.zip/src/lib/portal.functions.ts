import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const YEAR_OPTIONS = ["2029/30 (First Year)", "2028/29 (Second Year)", "2027/28 (Third Year)", "2027 (Fourth Year)"] as const;

const requestSchema = z.object({
  fullName: z.string().trim().min(2).max(120).regex(/^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'-]*$/),
  courseId: z.string().uuid(),
  rollNumber: z.string().trim().min(2).max(40).regex(/^[A-Za-z0-9/-]+$/),
  yearOfGraduation: z.enum(YEAR_OPTIONS),
  phone: z.string().regex(/^[6-9]\d{9}$/),
  email: z.string().trim().email().max(160),
  // The reference workflow collects an ID photo (JPG/PNG only) instead of a PDF.
  collegeIdPath: z.string().max(240).optional(),
  collegeIdMime: z.enum(["image/jpeg", "image/png"]).optional(),
  collegeIdSize: z.number().int().positive().max(5 * 1024 * 1024).optional(),
});

function publicClient() {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Backend configuration is incomplete.");
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        headers.set("apikey", key);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
        return fetch(input, { ...init, headers });
      },
    },
  });
}

export const listCourses = createServerFn({ method: "GET" }).handler(async () => {
  const { data, error } = await publicClient().from("courses").select("id,name,acronym").eq("is_active", true).order("name");
  if (error) throw new Error("Courses could not be loaded.");
  return data ?? [];
});

export const getPortalSettings = createServerFn({ method: "GET" }).handler(async () => {
  const { data, error } = await publicClient().from("portal_settings").select("active_batch,privacy_notice,retention_notice").eq("id", true).single();
  if (error) throw new Error("Portal settings could not be loaded.");
  return data;
});

export const submitStudentRequest = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => requestSchema.parse(input))
  .handler(async ({ data }) => {
    const db = publicClient();
    const { data: settings, error: settingsError } = await db.from("portal_settings").select("active_batch").eq("id", true).single();
    if (settingsError || !settings) throw new Error("The portal is temporarily unavailable.");
    const referenceId = `AVN-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const { data: inserted, error } = await db.from("student_requests").insert({
      reference_id: referenceId,
      full_name: data.fullName,
      course_id: data.courseId,
      roll_number: data.rollNumber,
      phone: data.phone,
      email: data.email.toLowerCase(),
      year_of_graduation: data.yearOfGraduation,
      college_id_path: data.collegeIdPath,
      college_id_mime: data.collegeIdMime,
      college_id_size: data.collegeIdSize,
      active_batch: settings.active_batch,
    } as never).select("reference_id,status").single();
    if (error) {
      const message = error.code === "23505" ? "A request already exists for these details. Use Track request to check its status." : "Your request could not be submitted. Please review the details and try again.";
      throw new Error(message);
    }
    return inserted;
  });

export const getRequestStatus = createServerFn({ method: "GET" })
  .inputValidator((input: { referenceId: string }) => z.object({ referenceId: z.string().trim().min(8).max(24) }).parse(input))
  .handler(async ({ data }) => {
    const { data: request, error } = await publicClient().rpc("get_request_status", { _reference_id: data.referenceId });
    if (error || !request?.[0]) throw new Error("No request was found with that reference ID.");
    return request[0];
  });

export const checkIsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!context) return false;
    const { supabase, userId } = context;
    const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    if (role?.some((entry) => entry.role === "admin" || entry.role === "reviewer")) return true;
    const { data: claimed } = await supabase.rpc("claim_admin_invite");
    return Boolean(claimed);
  });

export const getAdminSnapshot = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { supabase, userId } = context;
    const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    if (!role?.some((entry) => entry.role === "admin" || entry.role === "reviewer")) {
      const { data: claimed } = await supabase.rpc("claim_admin_invite");
      if (!claimed) {
      const { data: bootstrapped, error: bootstrapError } = await supabase.rpc("bootstrap_first_admin", { _user_id: userId });
      if (bootstrapError || !bootstrapped) throw new Error("You do not have access to the admin workspace.");
      }
    }
    const [{ data: requests }, { data: courses }, { data: settings }] = await Promise.all([
      supabase.from("student_requests").select("*, courses(name,acronym)").order("submitted_at", { ascending: false }),
      supabase.from("courses").select("id,name,acronym,is_active").order("name"),
      supabase.from("portal_settings").select("active_batch,privacy_notice,retention_notice").eq("id", true).single(),
    ]);
    return { requests: requests ?? [], courses: courses ?? [], settings };
  });

export const approveRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { requestId: string }) => z.object({ requestId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { data: result, error } = await context.supabase.rpc("approve_student_request", { _request_id: data.requestId, _actor_id: context.userId });
    if (error || !result?.[0]) throw new Error(error?.message ?? "This request could not be approved.");
    return result[0];
  });

export const updateRequestStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { requestId: string; status: "rejected" | "correction_requested"; reason: string }) => z.object({ requestId: z.string().uuid(), status: z.enum(["rejected", "correction_requested"]), reason: z.string().trim().min(3).max(500) }).parse(input))
  .handler(async ({ data, context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { data: updated, error } = await context.supabase.rpc("update_student_request_status", { _request_id: data.requestId, _actor_id: context.userId, _status: data.status, _reason: data.reason });
    if (error || !updated) throw new Error(error?.message ?? "The request status could not be updated.");
    return { ok: true };
  });

export const updatePortalSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { activeBatch: string }) => z.object({ activeBatch: z.string().trim().min(3).max(20) }).parse(input))
  .handler(async ({ data, context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { error } = await context.supabase.from("portal_settings").update({ active_batch: data.activeBatch }).eq("id", true);
    if (error) throw new Error("Settings could not be saved.");
    return { ok: true };
  });

export const listAdminInvites = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { data, error } = await context.supabase.from("admin_invites").select("id,email,created_at,expires_at,accepted_at").order("created_at", { ascending: false });
    if (error) throw new Error("Invites could not be loaded.");
    return data ?? [];
  });

export const createAdminInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { email: string }) => z.object({ email: z.string().trim().toLowerCase().email().max(255) }).parse(input))
  .handler(async ({ data, context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { error } = await context.supabase.from("admin_invites").insert({ email: data.email, invited_by: context.userId });
    if (error) throw new Error(error.code === "23505" ? "This email already has an open invite." : "The invite could not be created.");
    return { ok: true };
  });

export const revokeAdminInvite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    if (!context) throw new Error("Your session could not be verified.");
    const { error } = await context.supabase.from("admin_invites").delete().eq("id", data.id);
    if (error) throw new Error("The invite could not be removed.");
    return { ok: true };
  });
