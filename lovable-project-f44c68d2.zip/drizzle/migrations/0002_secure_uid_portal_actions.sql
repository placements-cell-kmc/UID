CREATE OR REPLACE FUNCTION public.get_request_status(_reference_id text)
RETURNS TABLE(reference_id text, status text, status_reason text, uid text, submitted_at timestamptz, active_batch text, course_name text)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT r.reference_id, r.status, r.status_reason, r.uid, r.submitted_at, r.active_batch, c.name
  FROM public.student_requests r
  JOIN public.courses c ON c.id = r.course_id
  WHERE upper(r.reference_id) = upper(trim(_reference_id))
  LIMIT 1;
$$;
GRANT EXECUTE ON FUNCTION public.get_request_status(text) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.bootstrap_first_admin(_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF _user_id IS NULL OR _user_id <> auth.uid() THEN
    RETURN false;
  END IF;
  IF EXISTS (SELECT 1 FROM public.user_roles) THEN
    RETURN EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin', 'reviewer'));
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (_user_id, 'admin');
  RETURN true;
END;
$$;
GRANT EXECUTE ON FUNCTION public.bootstrap_first_admin(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.update_student_request_status(_request_id uuid, _actor_id uuid, _status text, _reason text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF _actor_id IS NULL OR _actor_id <> auth.uid() OR NOT public.has_role(_actor_id, 'admin') AND NOT public.has_role(_actor_id, 'reviewer') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  IF _status NOT IN ('rejected', 'correction_requested') OR length(trim(_reason)) < 3 THEN
    RAISE EXCEPTION 'Invalid status update';
  END IF;
  UPDATE public.student_requests
  SET status = _status, status_reason = trim(_reason)
  WHERE id = _request_id AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request is not pending';
  END IF;
  INSERT INTO public.audit_events (request_id, actor_id, action, reason)
  VALUES (_request_id, _actor_id, _status, trim(_reason));
  RETURN true;
END;
$$;
GRANT EXECUTE ON FUNCTION public.update_student_request_status(uuid, uuid, text, text) TO authenticated;