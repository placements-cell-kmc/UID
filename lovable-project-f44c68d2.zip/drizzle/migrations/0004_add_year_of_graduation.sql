ALTER TABLE public.student_requests ADD COLUMN year_of_graduation TEXT;

CREATE OR REPLACE FUNCTION public.approve_student_request(_request_id UUID, _actor_id UUID)
RETURNS TABLE(uid TEXT, reference_id TEXT) LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_request public.student_requests;
  v_course public.courses;
  v_batch TEXT;
  v_serial INTEGER;
  v_uid TEXT;
BEGIN
  IF NOT public.has_role(_actor_id, 'admin') AND NOT public.has_role(_actor_id, 'reviewer') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  SELECT * INTO v_request FROM public.student_requests WHERE id = _request_id FOR UPDATE;
  IF v_request.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF v_request.status <> 'pending' THEN RAISE EXCEPTION 'Request is not pending'; END IF;
  SELECT * INTO v_course FROM public.courses WHERE id = v_request.course_id;
  v_batch := COALESCE(NULLIF(trim(v_request.year_of_graduation), ''), (SELECT active_batch FROM public.portal_settings WHERE id = true));
  INSERT INTO public.uid_counters (course_id, batch, next_serial) VALUES (v_course.id, v_batch, 2)
    ON CONFLICT (course_id, batch) DO UPDATE SET next_serial = public.uid_counters.next_serial + 1, updated_at = now();
  SELECT next_serial - 1 INTO v_serial FROM public.uid_counters WHERE course_id = v_course.id AND batch = v_batch;
  v_uid := v_course.acronym || lpad(v_serial::text, 3, '0');
  UPDATE public.student_requests SET status = 'approved', uid = v_uid, approved_by = _actor_id, approved_at = now(), active_batch = v_batch WHERE id = _request_id;
  INSERT INTO public.audit_events (request_id, actor_id, action, metadata) VALUES (_request_id, _actor_id, 'approved', jsonb_build_object('uid', v_uid, 'batch', v_batch));
  RETURN QUERY SELECT v_uid, v_request.reference_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.approve_student_request(UUID, UUID) TO authenticated, service_role;
GRANT SELECT ON public.student_requests TO anon;