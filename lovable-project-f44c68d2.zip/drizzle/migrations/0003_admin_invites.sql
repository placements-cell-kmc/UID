CREATE TABLE public.admin_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  invited_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT now() + interval '14 days',
  accepted_at timestamptz,
  accepted_by uuid
);
CREATE UNIQUE INDEX admin_invites_open_email ON public.admin_invites (lower(email)) WHERE accepted_at IS NULL;
GRANT SELECT, INSERT, DELETE ON public.admin_invites TO authenticated;
GRANT ALL ON public.admin_invites TO service_role;
ALTER TABLE public.admin_invites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view invites" ON public.admin_invites FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins create invites" ON public.admin_invites FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin') AND invited_by = auth.uid());
CREATE POLICY "Admins delete invites" ON public.admin_invites FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.claim_admin_invite()
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid := auth.uid(); _email text; _invite uuid;
BEGIN
  IF _uid IS NULL THEN RETURN false; END IF;
  SELECT email INTO _email FROM auth.users WHERE id = _uid AND email_confirmed_at IS NOT NULL;
  IF _email IS NULL THEN RETURN false; END IF;
  SELECT id INTO _invite FROM public.admin_invites
    WHERE lower(email) = lower(_email) AND accepted_at IS NULL AND expires_at > now()
    ORDER BY created_at DESC LIMIT 1 FOR UPDATE;
  IF _invite IS NULL THEN RETURN false; END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (_uid, 'admin') ON CONFLICT DO NOTHING;
  UPDATE public.admin_invites SET accepted_at = now(), accepted_by = _uid WHERE id = _invite;
  RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.claim_admin_invite() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.claim_admin_invite() TO authenticated;