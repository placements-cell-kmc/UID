CREATE OR REPLACE FUNCTION public.grant_placements_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL AND lower(NEW.email) = 'placements@kmc.du.ac.in' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.grant_placements_admin() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS on_auth_user_created_placements_admin ON auth.users;
CREATE TRIGGER on_auth_user_created_placements_admin AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_placements_admin();
DROP TRIGGER IF EXISTS on_auth_user_confirmed_placements_admin ON auth.users;
CREATE TRIGGER on_auth_user_confirmed_placements_admin AFTER UPDATE OF email_confirmed_at ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_placements_admin();