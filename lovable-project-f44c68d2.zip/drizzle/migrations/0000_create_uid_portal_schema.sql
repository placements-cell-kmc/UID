CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE public.app_role AS ENUM ('admin', 'reviewer');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read their own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL DEFAULT 'reviewer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read their own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated, service_role;

CREATE TABLE public.portal_settings (
  id BOOLEAN PRIMARY KEY DEFAULT TRUE,
  active_batch TEXT NOT NULL DEFAULT '2029/30',
  privacy_notice TEXT NOT NULL DEFAULT 'Your details are collected only for Placement Cell registration and official communication. Records are retained according to the Placement Cell retention policy.',
  retention_notice TEXT NOT NULL DEFAULT 'Registration records are retained only as long as required for placement administration and compliance.',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.portal_settings TO anon, authenticated;
GRANT UPDATE ON public.portal_settings TO authenticated;
GRANT ALL ON public.portal_settings TO service_role;
ALTER TABLE public.portal_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read portal settings" ON public.portal_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins can update portal settings" ON public.portal_settings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  acronym TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.courses TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.courses TO authenticated;
GRANT ALL ON public.courses TO service_role;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read active courses" ON public.courses FOR SELECT TO anon, authenticated USING (is_active = true OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage courses" ON public.courses FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update courses" ON public.courses FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete courses" ON public.courses FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.uid_counters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES public.courses(id),
  batch TEXT NOT NULL,
  next_serial INTEGER NOT NULL DEFAULT 1 CHECK (next_serial > 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (course_id, batch)
);
GRANT SELECT ON public.uid_counters TO authenticated;
GRANT ALL ON public.uid_counters TO service_role;
ALTER TABLE public.uid_counters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can read UID counters" ON public.uid_counters FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.student_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_id TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  course_id UUID NOT NULL REFERENCES public.courses(id),
  roll_number TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  college_id_path TEXT,
  college_id_mime TEXT,
  college_id_size INTEGER,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'correction_requested')),
  status_reason TEXT,
  uid TEXT UNIQUE,
  active_batch TEXT NOT NULL,
  approved_by UUID,
  approved_at TIMESTAMPTZ,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.student_requests TO anon;
GRANT SELECT, INSERT, UPDATE ON public.student_requests TO authenticated;
GRANT ALL ON public.student_requests TO service_role;
ALTER TABLE public.student_requests ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX student_requests_roll_lower_idx ON public.student_requests (lower(roll_number));
CREATE UNIQUE INDEX student_requests_email_lower_idx ON public.student_requests (lower(email));
CREATE UNIQUE INDEX student_requests_phone_idx ON public.student_requests (phone);
CREATE INDEX student_requests_status_idx ON public.student_requests (status);
CREATE INDEX student_requests_submitted_at_idx ON public.student_requests (submitted_at DESC);
CREATE POLICY "Anyone can submit a student request" ON public.student_requests FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Students can read their own request by reference" ON public.student_requests FOR SELECT TO anon, authenticated USING (false);
CREATE POLICY "Admins can read all student requests" ON public.student_requests FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));
CREATE POLICY "Admins can update student requests" ON public.student_requests FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer')) WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));

CREATE TABLE public.audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID REFERENCES public.student_requests(id) ON DELETE SET NULL,
  actor_id UUID,
  action TEXT NOT NULL,
  reason TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_events TO authenticated;
GRANT ALL ON public.audit_events TO service_role;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can read audit events" ON public.audit_events FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));

CREATE TABLE public.email_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID REFERENCES public.student_requests(id) ON DELETE SET NULL,
  recipient_email TEXT NOT NULL,
  template_key TEXT NOT NULL,
  delivery_status TEXT NOT NULL DEFAULT 'queued' CHECK (delivery_status IN ('queued', 'sent', 'failed')),
  provider_message_id TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at TIMESTAMPTZ
);
GRANT SELECT ON public.email_deliveries TO authenticated;
GRANT ALL ON public.email_deliveries TO service_role;
ALTER TABLE public.email_deliveries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can read email deliveries" ON public.email_deliveries FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'reviewer'));

INSERT INTO public.portal_settings (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
GRANT EXECUTE ON FUNCTION public.set_updated_at() TO authenticated, service_role;
CREATE TRIGGER profiles_set_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER portal_settings_set_updated_at BEFORE UPDATE ON public.portal_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER courses_set_updated_at BEFORE UPDATE ON public.courses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER uid_counters_set_updated_at BEFORE UPDATE ON public.uid_counters FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER student_requests_set_updated_at BEFORE UPDATE ON public.student_requests FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.approve_student_request(_request_id UUID, _actor_id UUID)
RETURNS TABLE(uid TEXT, reference_id TEXT) LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_request public.student_requests;
  v_course public.courses;
  v_settings public.portal_settings;
  v_serial INTEGER;
  v_uid TEXT;
BEGIN
  IF NOT public.has_role(_actor_id, 'admin') AND NOT public.has_role(_actor_id, 'reviewer') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  SELECT * INTO v_request FROM public.student_requests WHERE id = _request_id FOR UPDATE;
  IF v_request.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF v_request.status <> 'pending' THEN RAISE EXCEPTION 'Request is not pending'; END IF;
  SELECT * INTO v_course FROM public.courses WHERE id = v_request.course_id;
  SELECT * INTO v_settings FROM public.portal_settings WHERE id = true;
  INSERT INTO public.uid_counters (course_id, batch, next_serial) VALUES (v_course.id, v_settings.active_batch, 2)
    ON CONFLICT (course_id, batch) DO UPDATE SET next_serial = public.uid_counters.next_serial + 1;
  SELECT next_serial - 1 INTO v_serial FROM public.uid_counters WHERE course_id = v_course.id AND batch = v_settings.active_batch;
  v_uid := v_course.acronym || lpad(v_serial::text, 3, '0');
  UPDATE public.student_requests SET status = 'approved', uid = v_uid, approved_by = _actor_id, approved_at = now(), active_batch = v_settings.active_batch WHERE id = _request_id;
  INSERT INTO public.audit_events (request_id, actor_id, action, metadata) VALUES (_request_id, _actor_id, 'approved', jsonb_build_object('uid', v_uid));
  RETURN QUERY SELECT v_uid, v_request.reference_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.approve_student_request(UUID, UUID) TO authenticated, service_role;