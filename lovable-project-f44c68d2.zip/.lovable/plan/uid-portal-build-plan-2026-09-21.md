# UID Portal build plan

## Product outcome
Build the Avenues – The Placement Cell UID Portal for Kirori Mal College, with a public student request flow and a secure signed-in admin workspace.

## Confirmed decisions
- UID format: the exact workbook acronym followed immediately by a four-digit serial, for example `KMC2930BAE001`.
- Serial numbers increment independently for each course and are never reused.
- The active batch starts at `2029/30` and is editable by admins.
- The first admin is the signed-in project owner; roles remain separate from user profiles.
- The attached course workbook is the source of truth for the initial editable course mapping.
- The visual direction follows the supplied Avenues reference: deep navy, white, restrained yellow accent, serif display typography, clean corporate spacing, and responsive accessibility.

## Build phases
1. **Enable Lovable Cloud and establish the data model**
   - Add persistent tables for settings, courses, student requests, UID counters, audit events, and email delivery records.
   - Seed all workbook course/acronym pairs in the database.
   - Add server-side validation, uniqueness constraints, RLS, explicit public-schema grants, and separate user-role storage.
   - Store uploaded college IDs privately and expose them only through authenticated admin access.

2. **Create the public student experience**
   - Replace the blank home page with branded Avenues landing content and a clear “Generate UID” action.
   - Add the request form with course selection from the database, Indian phone/email validation, consent, file type/size checks, accessible errors, preview/remove behavior, and submission states.
   - Prevent duplicates by roll number, email, and phone, and show a friendly status/reference response when a prior request exists.
   - Show a confirmation screen with a reference ID and “Under Review”; include request tracking by reference ID.

3. **Create the protected admin workspace**
   - Add signed-in access using the project owner account and server-validated roles.
   - Build overview metrics, searchable/filterable/sortable/paginated requests, request detail review, private ID preview, duplicate warnings, and approve/reject/correction actions.
   - Make approval atomic: lock/increment the course counter, generate the UID, update the request, create the audit record, and prevent reuse or collisions.
   - Add bulk approval only for eligible requests, audit history, and settings for batch, courses, templates, and admin roles.

4. **Add communications and export**
   - Add acknowledgement, approval, rejection, and correction email templates with HTML and plain-text content.
   - Connect the server-side email delivery path and persist delivery status/errors so failed sends are visible to admins.
   - Add filtered Excel export with frozen/styled headers, filters, readable widths, and text-safe phone/roll-number columns.

5. **Polish and verify**
   - Add route-specific metadata for the public and admin pages, responsive layouts, keyboard/focus states, loading/empty/error/success states, and privacy/retention copy.
   - Verify the student submission, duplicate blocking, authenticated review, approval UID generation, counter behavior, export, and mobile/desktop rendering against the live preview.
   - Finish with setup/deployment notes and a short explanation of any provider connection still needed for live email delivery.

## Technical details
- Use the existing TanStack Start architecture, route files, design-system components, and server functions; do not introduce another router or framework.
- Keep public reads/actions unauthenticated only where safe. Keep all admin reads and mutations behind the signed-in role gate and server validation.
- Use database transactions/constraints rather than client-side state for uniqueness and UID allocation.
- Treat the uploaded screenshots as visual references, not page images; use the existing brand cues in the interface.
- Do not expose private ID files, service credentials, or role checks to the browser.
